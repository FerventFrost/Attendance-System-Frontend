// import '../css/main.css';
// import '../css/coponent-input.css';
// import '../css/formPage.css';
import '../css/coponent-input.css';
import '../css/addation.css';
import Waiting_illustration from '../img/form_illustration.png';

import useWaitingData_part from './WaitingData.part';

import Security_part from './Security.part';
import Personal_info from './Personal.part';
import Form_Input from './Contact.page';
import axios from 'axios';
import { repeat } from 'fontawesome';


function Form(props) {
    const {
        username,
        phone,
        gender,
        email,
        password,
        render } = useWaitingData_part();

    const OnclickEnventHandler = () => {
        const data = {
            name: username,
            email: email,
            password: password,
            phone: phone,
            gender: gender
        }
        if (username)
            axios.post("https://attendence123.herokuapp.com/employee", data)
                .then(res => { console.log(res); })
                .catch(err => { console.log(err); })
    }

    if (props.isToken) {
        return (
            <div className="main_content main_content_form">
                {/* Form Wrappe */}
                <div className="header">Welcome!! Have a nice day.</div>
                {/* <img className='Illus-imge' src={Waiting_illustration} /> */}
                <form className='Form-Data' style={{backgroundImage: `url(${Waiting_illustration})` ,backgroundRepeat: "no-repeat", backgroundPosition: 'end', backgroundPosition : "right bottom"}}>
                    {/* flex direction col */}
                    <div className='main-div'>
                        {/* flex direct row */}
                        <div>
                            <Form_Input Input_data={[["ID", "number"], ["Password", "text"]]}/>
                            <Form_Input Input_data={[["Name", "text"], ["Gender", "text"]]}/>
                            <Form_Input Input_data={[["Email", "email"], ["Phone", "number"]]}/>
                        </div>
                        <div className='employee-part'>
                            <Form_Input Input_data={[["Shift Duration", "number"], ["Start Time", "text"], ["Salary", "number"]]}/>
                        </div>
                    </div>

                    <div className='Form-Submit' >
                        
                            <button onSubmit={OnclickEnventHandler()}>Submit</button>
                        
                    </div>

                </form>
            </div>
        );
    }
    else {
        return (
            <div className="main_content main_content_form">
                {/* Form Wrappe */}
                <div className="header">Welcome!! Have a nice day.</div>
                {/* <img className='Illus-imge' src={Waiting_illustration} /> */}
                <form className='Form-Data'>
                    {render}
                    <button onSubmit={OnclickEnventHandler()}>Submit</button>
                </form>
            </div>
        );
    }
}


export default Form;