

import { useState, useEffect } from 'react';
import axios from 'axios';
import { render } from '@testing-library/react';


function useWaitingData_part() {


    // const formInput = [["Name", "text"], ["Email", "email"], ["Password", "password"], ["Phone", "text"], ["Gender", "text"],["Gender", "text"],["Gender", "text"],["Gender", "text"]];
    const [username, setusername] = useState("");
    const [phone, setphone] = useState("");
    const [email, setemail] = useState("");
    const [password, setpassword] = useState("");
    const [gender, setgender] = useState("");

    const data = {
        username: username,
        phone: phone,
        gender: gender,
        email: email,
        password: password
    };
    return {
        username,
        phone,
        gender,
        email,
        password,
        render: (
            <div className="">

                <div className="description-part">
                    <h2>Personal Information</h2>
                    <p>Enter all your personal data miust be a data here to know awdsad is good<br />and thawdsa is ad ada</p>
                </div>
                <div className="inputs-part">

                    <div>
                        <div className="group">
                            <input onChange={e => { setusername(e.target.value) }} placeholder=" " type="text" required="required" />
                            <span className="highlight"></span>
                            <span className="bar"></span>
                            <label>user name</label>
                        </div>
                    </div>
                    <div>
                        <div className="group">
                            <input onChange={e => { setphone(e.target.value) }} placeholder=" " type="number" required="required" />
                            <span className="highlight"></span>
                            <span className="bar"></span>
                            <label>phone</label>
                        </div>
                    </div>
                    <div>
                        <div className="group">
                            <input onChange={e => { setemail(e.target.value) }} placeholder=" " type="email" required="required" />
                            <span className="highlight"></span>
                            <span className="bar"></span>
                            <label>email</label>
                        </div>
                    </div>
                    <div>
                        <div className="group">
                            <input onChange={e => { setpassword(e.target.value) }} placeholder=" " type="password" required="required" />
                            <span className="highlight"></span>
                            <span className="bar"></span>
                            <label>password</label>
                        </div>

                    </div>
                    <div>
                        <div className="group">
                            <input onChange={e => { setgender(e.target.value) }} placeholder=" " type="text" required="required" />
                            <span className="highlight"></span>
                            <span className="bar"></span>
                            <label>Gender</label>
                        </div>

                    </div>

                </div>

            </div>
        )
    }

}


export default useWaitingData_part;