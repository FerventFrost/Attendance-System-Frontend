

function Form_Input({ Label, Description, Input_data }) {

    return (
        <div className="Form_Container">
            <div className="label_conatiner">
                <h2>Data</h2>
                <p>This Part is concerned with data input</p>
            </div>
            <div className="Input_container">
                {/* {Input_data.map((value, key) => {
                    return ( */}
                        <div >
                            <div className="group">
                                <input placeholder=" " type="text" required="required" />
                                <span className="highlight"></span>
                                <span className="bar"></span>
                                <label>Name</label>
                            </div>
                        </div>
                        <div >
                            <div className="group">
                                <input placeholder=" " type="text" required="required" />
                                <span className="highlight"></span>
                                <span className="bar"></span>
                                <label>Name</label>
                            </div>
                        </div>
                {/* })} */}
                {/* })} */}
            </div>
        </div>
    );
}

export default Form_Input;


