import { Link } from 'react-router-dom';
import '../css/Waiting_card.css';

function WaitingCard() {
    return (

        <div class="main_content">
            <div class="WaitingCard-class">

                <div class="cards">
                    <div class="card card-1">
                        <div class="card__icon"><i class="fas fa-bolt"></i></div>
                        <h2 class="card__title">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</h2>
                        <p class="card__apply">
                            <Link class="card__link" to="/form">Apply Now <i class="fas fa-arrow-right"></i></Link>
                        </p>
                    </div>

                    <div class="card card-3">
                        <div class="card__icon"><i class="fas fa-bolt"></i></div>
                        <h2 class="card__title">Ut enim ad minim veniam.</h2>
                        <p class="card__apply">
                            <Link class="card__link" to="/form">Apply Now <i class="fas fa-arrow-right"></i></Link>
                        </p>
                    </div>
                    <div class="card card-4">
                        <div class="card__icon"><i class="fas fa-bolt"></i></div>
                        <h2 class="card__title">Quis nostrud exercitation ullamco laboris nisi.</h2>
                        <p class="card__apply">
                            <Link class="card__link" to="/form">Apply Now <i class="fas fa-arrow-right"></i></Link>
                        </p>
                    </div>

                </div>
            </div>
        </div>
    );
}

export default WaitingCard;