import '../css/main.css';
import '../css/table.css';
// import '../css/table.addtion.css';

import Thead from "./thead.part";
import Tbody from "./tbody.part";
import axios from 'axios';
import React, { useState, useEffect } from 'react';


function Table(props) {

    const [UserData, setUserData] = useState([])
    const [PageNumber, setPageNumber] = useState(0)

    useEffect(() => {
        if (props.token)
            axios.get("https://attendence123.herokuapp.com/employee", { headers: { authorization: props.token } })
                .then(res => { setUserData(res.data); })
                .catch(err => { console.log(err); })
    }, [props.token])

    return (
        <div className="main_content">

            <div>
                <div className="d1214">
                    <h2 className="table-header">Mangement Table</h2>
                    <button onClick={() => {if(PageNumber < (UserData.length/8 -1 ))setPageNumber(PageNumber+1)}} className='Paggination-Button'>Next</button>
                    <button onClick={() => {if(PageNumber >0)setPageNumber(PageNumber-1)} } className='Paggination-Button'>pervious</button>
                </div>
                {/* Table Content */}
                <table className='Emp-table'>
                    <Thead />
                    <Tbody Data={UserData.slice(0 + 8 * PageNumber, 8 + 8 * PageNumber)} />
                </table>
            </div>
        </div>
    );

}

export default Table;