
function Tbody(props) {
    if (props.Data.length !== 0) {
        console.log(props.Data);
        return (
            <tbody>
                {props.Data.map((value) => {
                    return (
                        <tr key={value.id}>
                            <td className='p-id'>
                                {value.id}
                            </td>
                            <td>
                                {value.name}
                            </td>

                            <td>
                                {value.email}
                            </td>

                            <td>
                                {value.phone}
                            </td>

                            <td>
                                {value.active === true ?<h5 className="status-label inbox">Member</h5>: <h5 className="status-label member">Waiting</h5>}
                            </td>

                        </tr>
                    );
                })}

            </tbody>
        );
    }
    else { return (<tbody></tbody>); }
}

export default Tbody;