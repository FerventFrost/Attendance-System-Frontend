

function Thead() {
    return (
        <thead>
            <tr>
                {/* <th className="p-checkbox">
                    <input type="checkbox" name="thbox" id="thbox" />
                </th> */}
                <th className="p-id">
                    ID
                </th>
                <th>
                    Name
                </th>

                <th>
                    Email
                </th>
                <th>
                    Phone Number
                </th>
                <th>
                    Status
                </th>
            </tr>
        </thead>
    );
}

export default Thead;